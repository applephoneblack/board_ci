<?php

class Board_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        // url 헬퍼를 로드해서 다른 곳에서 함수 사용 가능
        $this->load->helper('url');
    }

    public function store($file1="")
    {
        $data = [
            'title' => $this->input->post("title"),
            'contents' => $this->input->post("contents"),
            'regdate' => date("Y-m-d H:i:s"),
            'author_email' => $this->session->userdata('email') // 작성자 이메일 추가
        ];

        if ($file1 !=""){
            $data['file'] = $file1; // 파일 필드에 파일명 설정
        }
        $result = $this->db->insert("boards", $data);
        return $result;
    }

    public function search($keyword)
    {
        $this->db->like('title', $keyword);
        // 다른 필요한 검색 조건을 추가할 수 있습니다.
        $query = $this->db->get('boards');
        return $query->result();
    }


    public function get($idx)
    {
        $board = $this->db->get_where('boards', ['idx' => $idx])->row();
        return $board;
    }

    public function getAll($type = '', $limit = 20, $page = 1)
    {
        // 전체 게시물 카운트
        // 전체 게시물 가져오기

        if ($type == 'count') {

            $board = $this->db->get('boards')->num_rows();

        } else {
            $this->db->limit($limit,$page);
            $this->db->order_by('idx', 'DESC');
            $board = $this->db->get('boards')->result();

        }
        return $board;


    }

    public function update($idx, $file1 = "")
    {
        $data = [
            'title' => $this->input->post("title"),
            'contents' => $this->input->post("contents"),
        ];
        if ($file1 != "") {
            $data['file'] = $file1;
        }

        $this->db->where('idx', $idx);
        $result = $this->db->update("boards", $data);
        return $result;
    }


    public function delete($idx)
    {
        $result = $this->db->delete("boards", array("idx" => $idx));

        return $result;
    }

    public function increase_views($idx) {
        // 현재 조회수 가져오기
        $board = $this->get($idx);
        $current_views = $board->views;

        // 조회수 증가 및 업데이트
        $new_views = $current_views + 1;
        $this->db->where('idx', $idx);
        $this->db->update('boards', array('views' => $new_views));
    }

}