<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

</head>
<body>

환영합니다.

<?php if ($this->session->userdata('email')) : ?>
    <p><?= $this->session->userdata('email'); ?>님이 로그인 중입니다.</p>
    <br>
    <a href="/members/logout">로그아웃</a>
<?php else : ?>
    <a href="/members/login">로그인</a>
    <br><br>
    <a href="/members/join">회원가입</a>
<?php endif; ?>

<br><br>

<a href="/board">게시판</a>
<br><br>
<a href="/calendar">달력</a>



</body>
</html>