<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>회원가입</title>
    <link rel="stylesheet" href="/assets/css/login.css">
</head>
<body>
    <div class="login-wrapper">
        <h2>회원가입</h2>
        <form method="post" action="/members/store" id="login-form">
            <input type="text" name="email" placeholder="Email" value="">
            <input type="password" name="password" placeholder="Password" value="">

            <input type="submit" value="저장하기">
        </form>
    </div>

</body>
</html>a