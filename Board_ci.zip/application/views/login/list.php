<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        table {
            width: 30%;
            border: 1px solid #444444;
        }

        th, td {
            border: 1px solid #444444;
        }
    </style>
</head>
<body>

회원 리스트 화면

<table>
    <tr>
        <th>email</th>
        <th>가입일</th>
        <th>관리</th>
    </tr>
    <?php
    foreach ($list as $ls) {
        ?>

        <tr>
            <td><?= $ls->email; ?></td>
            <td><?= $ls->regdate; ?></td>
            <td>
                <a href="/members/show/<?= $ls->idx; ?>">View</a>
                &nbsp;
                <a href="/members/edit/<?= $ls->idx; ?>">Edit</a>
                &nbsp;
                <a href="/members/delete/<?= $ls->idx; ?>">Delete</a>
            </td>
        </tr>

        <?php
    }
    ?>
    <tr>
        <th colspan="3">
            <?=$pages;?>
        </th>
    </tr>
</table>


<a href="/members/join">회원가입</a>

</body>
</html>


