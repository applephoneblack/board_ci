게시판 글 수정 화면입니다.

<form name="bfpm" action="/board/update/<?= $edit->idx; ?>" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_method" value="PUT">
    <table border="1">
        <tr>
            <th>제목</th>
            <td>
                <input type="text" name="title" value="<?= $edit->title; ?>">
            </td>
        </tr>
        <tr>
            <th>내용</th>
            <td>
                <textarea name="contents" rows="8"><?= $edit->contents; ?></textarea>
            </td>
        </tr>
        <tr>
            <th>파일</th>
            <td>
                <?php
                if ($edit->file){
                    echo "<img src ='/uploads/".$edit->file." 'width='100px'/>";
                }
                ?>
                <p>
                    <input type="file" name="file_1" value="">
                </p>
            </td>
        </tr>
        <tr>
            <th colspan="2">
                <input type="submit" value="수정하기" onclick="return confirmEdit();">
                <a href="/board">목록</a>
            </th>

        </tr>
    </table>
</form>

<script>
    function confirmEdit() {
        // 수정하기 버튼을 눌렀을 때 확인 창을 띄우고, 사용자가 확인하면 true를 반환하여 form을 제출하고,
        // 취소하면 false를 반환하여 form을 제출하지 않음
        return confirm('수정하시겠습니까?');
    }
</script>