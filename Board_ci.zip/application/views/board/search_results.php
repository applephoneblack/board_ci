<?php if (!empty($search_results)): ?>
    <ul>
        <?php foreach ($search_results as $result): ?>
            <li><?= $result->title; ?></li>

        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>검색 결과가 없습니다.</p>
<?php endif; ?>