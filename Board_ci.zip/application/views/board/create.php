게시판 글쓰기 화면입니다.

<form name="bfpm" action="/board/store" method="post" enctype="multipart/form-data">
    <table board="1">
        <tr>
            <th>작성자 이메일</th>
            <td>
                <input type="text" name="author_email" value="<?= $this->session->userdata('email'); ?>" readonly>
            </td>
        </tr>
        <tr>
        <tr>
            <th>제목</th>
            <td>
                <input type="text" name="title" value="">
            </td>
        </tr>
        <tr>
            <th>내용</th>
            <td>
                <textarea name="contents" rows="8"></textarea>
            </td>
        </tr>
        <tr>
            <th>파일</th>
            <td>
                <input type="file" name="file_1">
            </td>
        </tr>
        <tr>
            <th colspan="2">
                <input type="submit" value="저장">
            </th>
        </tr>
    </table>
</form>