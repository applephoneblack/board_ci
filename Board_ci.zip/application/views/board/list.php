<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        table {
            width: 30%;
            border: 1px solid #444444;
        }

        th, td {
            border: 1px solid #444444;
        }
    </style>
</head>
<body>

게시판 리스트입니다.

<form action="/board/search" method="get">
    <input type="text" name="keyword" placeholder="검색어를 입력하세요">
    <button type="submit">검색</button>
</form>


<form action="/board/multi_delete" method="post">
    <table>
        <tr>
            <th>체크</th>
            <th>제목</th>
            <th>파일</th>
            <th>작성일</th>
            <th>관리</th>
            <th>조회수</th>
        </tr>
        <?php foreach ($list as $ls): ?>
            <tr>
                <td><input type="checkbox" name="selected_items[]" value="<?= $ls->idx; ?>"></td>
                <td><?= $ls->title; ?></td>
                <td>
                    <?php if ($ls->file): ?>
                        <img src="/uploads/<?= $ls->file; ?>" width="100px"/>
                    <?php endif; ?>
                </td>
                <td><?= $ls->regdate; ?></td>
                <td>
                    <a href="/board/show/<?= $ls->idx; ?>">View</a>
                    &nbsp;
                    <a href="/board/edit/<?= $ls->idx; ?>">Edit</a>
                    &nbsp;
                    <a href="/board/delete/<?= $ls->idx; ?>">Delete</a>
                </td>
                <td><?= $ls->views; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <button type="submit">선택된 항목 삭제</button>
</form>


<a href="/board/create">글쓰기</a>
<br><br>
<a href="/">메인</a>

<!-- 페이지 링크 추가 -->
<tr>
    <th colspan="5">
        <?= $pages; ?>
    </th>
</tr>


</body>
</html>


