<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    table {
        width: 30%;
    }
</style>
<body>

<table border="1">
    <tr>
        <th>제목</th>
        <td><?= $view->title; ?></td>
    </tr>
    <tr>
        <th>내용</th>
        <td><?= $view->contents; ?></td>
    </tr>
    <tr>
        <th>파일</th>
        <td>
            <?php
            if ($view->file){
                echo "<img src ='/uploads/".$view->file." 'width='100px'/>";
            }
            ?>
        </td>
    </tr>
    <tr>
        <th>작성일</th>
        <td><?= $view->regdate; ?></td>
    </tr>
    <tr>
        <th>조회수</th>
        <td><?= $view->views; ?></td>
    </tr>
    <tr>
        <th colspan="2">
            <a href="/board">목록</a>
        </th>
    </tr>


</table>

</body>
</html>