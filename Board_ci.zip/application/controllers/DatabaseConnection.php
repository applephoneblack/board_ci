<?php
class DatabaseConnection extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function index()
    {
        $result = $this->db->query('select * from users')->result_array();
        foreach ($result as $item) {
            echo $item['username'].'<br>';
        }

    }
}