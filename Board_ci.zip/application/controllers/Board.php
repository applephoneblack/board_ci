<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Board extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['form_validation','session']);

        $this->load->model('Board_model', 'board');

        if (!$this->session->userdata('email')) {
            redirect('/members/login');
        }
    }

    public function index()
    {
        $this->load->library('pagination');

        $config['base_url'] = '/board/';
        $config['total_rows'] = $this->board->getAll('count',0,0);
        $config['per_page'] = 20;
        $config['uri_segment'] = 2;
        $config['num_links'] = 10;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data['pages'] = $this->pagination->create_links();

        $data['list'] = $this->board->getAll('all',$config['per_page'],$page);
        $this->load->view('board/list', $data);
    }

    public function search()
    {
        $keyword = $this->input->get('keyword');

        // 게시판 모델에서 검색어를 포함한 게시물을 검색합니다.
        $data['search_results'] = $this->board->search($keyword);

        // 검색 결과를 뷰에 전달하여 표시합니다.
        $this->load->view('board/search_results', $data);
    }


    public function create()
    {
        $this->load->view('board/create');
    }

    public function store()
    {
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('contents', 'Contents', 'required');

        if ($this->form_validation->run()) {
            $file1 = ""; // 초기화

            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '0';
            $config['max_width'] = '0';
            $config['max_height'] = '0';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if (!$this->upload->do_upload("file_1")) {
                $error = array('error' => $this->upload->display_errors());
                echo "file upload error :".print_r($error);
            } else{
                $file1 = $this->upload->data('file_name');

            }

            $this->board->store($file1);
            // Board_model url 헬퍼로 인해 redirect 사용가능해짐
            redirect('/board');
        } else {
            echo "Error";
        }
    }

    public function show($idx)
    {
        $board = $this->board->get($idx);

        if ($board) {
            $this->board->increase_views($idx);
            $data['view'] = $board;
            $this->load->view('board/show', $data);
        }

    }

    public function edit($idx)
    {
        // 게시물 정보를 가져옵니다.
        $data['edit'] = $this->board->get($idx);

        // 로그인한 사용자의 이메일을 가져옵니다.
        $user_email = $this->session->userdata('email');

        // 로그인한 사용자의 이메일과 게시물의 작성자 이메일을 비교합니다.
        if ($user_email && $data['edit']->author_email === $user_email) {
            // 작성자와 일치하는 경우 수정 페이지를 표시합니다.
            $this->load->view('board/edit', $data);
        } else {
            // 작성자와 다른 경우에는 권한이 없다는 메시지를 출력하거나 다른 페이지로 리디렉션할 수 있습니다.
            echo "수정할 권한이 없습니다.";
        }
    }

    public function update($idx)
    {
        // 사용자가 수정한 게시물 데이터를 가져옵니다.
        $title = $this->input->post("title");
        $contents = $this->input->post("contents");

        // 로그인한 사용자의 이메일을 가져옵니다.
        $user_email = $this->session->userdata('email');

        // 게시물 정보를 가져옵니다.
        $board = $this->board->get($idx);

        // 파일 변수 초기화
        $file1 = "";

        // 로그인한 사용자의 이메일과 게시물의 작성자 이메일을 비교합니다.
        if ($user_email && $board->author_email === $user_email) {
            // 파일 업로드 설정
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '0';
            $config['max_width'] = '0';
            $config['max_height'] = '0';

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            // 파일이 업로드되었는지 확인합니다.
            if ($this->upload->do_upload("file_1")) {
                // 파일 업로드 성공 시, 이전 파일을 삭제하고 새 파일로 업데이트합니다.
                $old_file = $board->file;
                if ($old_file && file_exists('./uploads/' . $old_file)) {
                    unlink(FCPATH . '/uploads/' . $old_file);
                }

                // 수정된 파일 저장
                $file1 = $this->upload->data('file_name');
                echo "file upload success: " . $file1;
            } else {
                // 파일 업로드 실패 시, 공백으로 설정합니다.
                $error = array('error' => $this->upload->display_errors());
                echo "file upload error :" . print_r($error);
            }

            // 게시물 업데이트
            $this->board->update($idx, $file1);
            echo "<script>alert('수정되었습니다.'); window.location.href='/board';</script>";
            exit;
        } else {
            // 작성자와 다른 경우에는 권한이 없다는 메시지를 출력하거나 다른 페이지로 리디렉션할 수 있습니다.
            echo "수정할 권한이 없습니다.";
        }
    }



    public function delete($idx)
    {
        // 로그인한 사용자의 이메일을 가져옵니다.
        $user_email = $this->session->userdata('email');

        // 게시물 정보를 가져옵니다.
        $board = $this->board->get($idx);

        // 로그인한 사용자의 이메일과 게시물의 작성자 이메일을 비교합니다.
        if ($user_email && $board->author_email === $user_email) {
            // 작성자와 일치하는 경우에만 이전 파일 제거 후 게시물을 삭제합니다.
            $old_file = $this->board->get($idx);
            $this->board->delete($idx);

            // 파일이 존재하면 삭제합니다.
            if ($old_file && file_exists('./uploads/' . $old_file->file)) {
                unlink(FCPATH . 'uploads/' . $old_file->file);
                echo "Deleted";
            } else {
                echo "Found some error";
            }

            echo "<script>alert('삭제되었습니다.'); window.location.href='/board';</script>";
            exit;
        } else {
            // 작성자와 다른 경우에는 권한이 없다는 메시지를 출력하거나 다른 페이지로 리디렉션할 수 있습니다.
            echo "삭제할 권한이 없습니다.";
        }
    }

    public function multi_delete()
    {
        // 선택된 항목들의 ID 배열 가져오기
        $selected_items = $this->input->post('selected_items');

        if (!empty($selected_items)) {
            // 선택된 항목들을 반복하면서 삭제
            foreach ($selected_items as $idx) {
                // 게시물 정보 가져오기
                $board = $this->board->get($idx);

                // 현재 로그인한 사용자의 이메일 가져오기
                $user_email = $this->session->userdata('email');

                // 작성자와 현재 로그인한 사용자가 일치하는지 확인
                if ($board && $board->author_email === $user_email) {
                    // 작성자와 일치하면 삭제
                    $this->board->delete($idx);
                } else {
                    echo "<script>alert('삭제할 수 있는 권한이 없습니다.'); window.location.href='/board';</script>";
                    exit;
                }
            }
            echo "<script>alert('삭제되었습니다.'); window.location.href='/board';</script>";
            exit;
        } else {
            echo "<script>alert('삭제할 항목을 선택해주세요.'); window.location.href='/board';</script>";
            exit;
        }
    }

    public function example()
    {

    }





}